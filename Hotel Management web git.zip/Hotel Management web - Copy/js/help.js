



const helpBtn = document.getElementById("helpBtn");
const chatBox = document.getElementById("chatBox");
const closeBtn = document.getElementById("closeBtn");
const chatBody = document.getElementById("chatBody");
const inputField = chatBox.querySelector(".chat-footer input");
const sendBtn = chatBox.querySelector(".chat-footer button");

// helpBtn.onclick = () => {
//   chatBox.classList.toggle("show");

//   if (chatBox.classList.contains("show")) {
//     chatBody.innerHTML = "";
//     const username = localStorage.getItem("username") || "there";

//     appendMessage("bot", `Hi ${username}! 👋<br>How can I assist you today?`);
//     appendMessage("bot", "Choose an option below or type your question.");

//     const optionsDiv = document.createElement("div");
//     optionsDiv.className = "options";
//     optionsDiv.id = "options";
//     optionsDiv.innerHTML = `
//       <button>Cancel booking</button>
//       <button>Change booking</button>
//       <button>Get refund status</button>
//       <button>Update profile</button>
//       <button>View offers</button>
//       <button>Contact support</button>
//     `;
//     chatBody.appendChild(optionsDiv);
//     optionsDiv.addEventListener("click", handleOptionClick);
//   }
// };

closeBtn.onclick = () => chatBox.classList.remove("show");

function handleOptionClick(e) {
  if (e.target.tagName === "BUTTON") {
    const userMessage = e.target.innerText;
    appendMessage("user", userMessage);
    respondTo(userMessage);
  }
}

sendBtn.onclick = sendMessage;

inputField.addEventListener("keypress", (e) => {
  if (e.key === "Enter") sendMessage();
});

function sendMessage() {
  const msg = inputField.value.trim();
  if (msg !== "") {
    appendMessage("user", msg);
    respondTo(msg);
    inputField.value = "";
  }
}

function appendMessage(sender, text) {
  const div = document.createElement("div");
  div.className = `message ${sender}`;
  div.innerHTML = text;
  chatBody.appendChild(div);
  chatBody.scrollTop = chatBody.scrollHeight;
  return div;
}

function respondTo(message) {
  let response = "I'm not sure I understand. Could you please clarify?";
  message = message.toLowerCase();

  if (message.includes("cancel")) {
    response = "Sure, I can help you cancel your booking. Please provide your booking ID.";
  } else if (message.includes("change")) {
    response = "Let’s get your booking changed. What would you like to modify?";
  } else if (message.includes("refund")) {
    response = "Checking your refund status... Please provide your booking ID.";
  } else if (message.includes("profile")) {
    response = "You can update your profile in the account settings.";
  } else if (message.includes("offer")) {
    response = "Here are the latest offers: 10% off on weekend stays!";
  } else if (message.includes("support")) {
    response = "Our support team is available 24/7. Connecting you now...";
  } else if (message.includes("hi")) {
    const username = localStorage.getItem("username") || "there";
    response = `Hey ${username}! How can I help you today?`;
  }

  showThinkingThenRespond(response);
}

function showThinkingThenRespond(finalResponse) {
  const thinkingDiv = appendMessage("bot", "typing...");
  thinkingDiv.classList.add("small");

  setTimeout(() => {
    thinkingDiv.remove();
    appendMessage("bot", finalResponse);


    const sound = document.getElementById("notifySound");
    if (sound) sound.play();
  }, 1000);
}

